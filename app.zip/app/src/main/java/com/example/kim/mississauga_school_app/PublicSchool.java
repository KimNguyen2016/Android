package com.example.kim.mississauga_school_app;

/**
 * Created by Kim on 7/6/2016.
 */
public class PublicSchool {
    int iconId;
    String address;
    String phone;
    String website;

    public PublicSchool(int id, String address, String phone, String web){
        this.iconId = id;
        this.address = address;
        this.phone = phone;
        this.website = web;
    }

    public int getIconId() {
        return iconId;
    }

    public void setIconId(int iconId) {
        this.iconId = iconId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }
}
