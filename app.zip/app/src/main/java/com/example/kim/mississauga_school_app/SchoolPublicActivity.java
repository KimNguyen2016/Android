package com.example.kim.mississauga_school_app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SchoolPublicActivity extends Activity{

    ListView publicList;

    String[] info = {"Fairview Public School \n\n3590 Joan Dr, Mississauga \n\n Phone: 905 - 277 - 0281 \n\n Web: http://schools.peelschools.org/1360/Pages/default.aspx \n",
                     "The Valleys Senior Public School \n\n 1235 Mississauga Valley B, Mississauga \n\n Phone: 905 - 275 - 5125 \n\n Web: http://schools.peelschools.org/1354/Pages/default.aspx \n",
                     "Huntington Ridge Public School \n\n 345 Hungtington Ridge Dr., Mississauga \n\n Phone: 905 - 890 - 2170 \n\n Web: http://schools.peelschools.org/1154/Pages/default.aspx \n",
                     "Barondale Public School \n\n 200 Barondale Dr, Mississauga \n\n Phone: 905 - 502 - 1880 \n\n Web: http://schools.peelschools.org/1149/Pages/default.aspx \n",
                     "Champlain Trail Schoo \n\n 895 Ceremonial Dr, Mississauga \n\n Phone: 905 - 568 - 1836 \n\n Web: http://schools.peelschools.org/1155/Pages/default.aspx \n",
                     "Camilla Road Senior Public School \n\n 201 Cherry Post Dr, Mississauga \n\n Phone: 905 - 270 - 0845 \n\n Web: http://schools.peelschools.org/1353/Pages/default.aspx \n",
                     "Dunrankin Dr. Public School \n\n 3700 Durankin Dr, Mississauga \n\n Phone: 905 - 677 - 2202\n\n Web: http://schools.peelschools.org/1108/Pages/default.aspx \n"
                    };

    Integer[] imageId = {R.drawable.schoollogo,
                         R.drawable.schoollogo,
                         R.drawable.schoollogo,
                         R.drawable.schoollogo,
                         R.drawable.schoollogo,
                         R.drawable.schoollogo,
                         R.drawable.schoollogo
                        };

    public void startPublicMap(View v){
        Intent intent = new Intent(SchoolPublicActivity.this,publicmap.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_public);

        CustomListPublic adapter = new CustomListPublic(SchoolPublicActivity.this, info, imageId);
        publicList = (ListView)findViewById(R.id.listViewPublic);
        publicList.setAdapter(adapter);
        publicList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Toast.makeText(SchoolPublicActivity.this, "You Clicked at " + info[+ position], Toast.LENGTH_SHORT).show();
            }
        });
    }

}

