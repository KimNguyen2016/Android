package com.example.kim.mississauga_school_app;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class SearchActivity extends AppCompatActivity {

    Spinner spinner1;
    Spinner spinner2;

    ArrayAdapter<CharSequence> adapter1;
    ArrayAdapter<CharSequence> adapter2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        spinner1 = (Spinner) findViewById(R.id.spinnerType);
        spinner2 = (Spinner) findViewById(R.id.spinnerGrade);

        adapter1 = ArrayAdapter.createFromResource(this, R.array.type_names, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter1);

        adapter2 = ArrayAdapter.createFromResource(this, R.array.grade_names, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);

        // spinner Type
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            Button publicBtn = (Button)findViewById(R.id.btnPublic);
            Button catholicBtn = (Button)findViewById(R.id.btnCatholic);
            Button privateBtn = (Button)findViewById(R.id.btnPrivate);

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                String spinner1_item = spinner1.getSelectedItem().toString();
                spinner1_item = spinner1_item.replace(" ", "");

                TextView spin1_text = (TextView)findViewById(R.id.txtType);
                spin1_text.setText(spinner1_item);

                switch (spinner1_item){
                    case "PublicSchool":
                        Toast.makeText(SearchActivity.this, "You selected Public School", Toast.LENGTH_SHORT).show();
                        publicBtn.setClickable(true);
                        catholicBtn.setClickable(false);
                        privateBtn.setClickable(false);
                        break;
                    case "CatholicSchool":
                        Toast.makeText(SearchActivity.this, "You selected Catholic School", Toast.LENGTH_SHORT).show();
                        catholicBtn.setClickable(true);
                        publicBtn.setClickable(false);
                        privateBtn.setClickable(false);
                        break;
                    case "PrivateSchool":
                        Toast.makeText(SearchActivity.this, "You selected Private School", Toast.LENGTH_SHORT).show();
                        privateBtn.setClickable(true);
                        catholicBtn.setClickable(false);
                        publicBtn.setClickable(false);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        // spinner Grade

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                String spinner2_item = spinner2.getSelectedItem().toString();
                //gradeVal= spinner2_item;
                TextView spin2_text = (TextView)findViewById(R.id.txtGrade);
                spin2_text.setText(spinner2_item);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    public void startExitButton(View v) {
        System.exit(0);
    }

    public void startPublicButon(View v){
        Intent intent = new Intent(this, SchoolPublicActivity.class);
        startActivity(intent);
    }

    public void startCatholicButon(View v){
        Intent intent = new Intent(this, SchoolCatholicActivity.class);
        startActivity(intent);
    }

    public void startPrivateButon(View v){
        Intent intent = new Intent(this, SchoolPrivateActivity.class);
        startActivity(intent);
    }
}

