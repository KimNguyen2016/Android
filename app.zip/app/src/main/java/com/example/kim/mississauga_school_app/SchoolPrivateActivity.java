package com.example.kim.mississauga_school_app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SchoolPrivateActivity extends Activity{

    ListView privateList;

    String[] info = {"Mentor College \n\n40 Forest Ave, Mississauga \n\n Phone: 905 - 271 - 3393 \n\n Web: mentorcollege.edu \n",
            "Montessori Private School \n\n 305 Matheson Blvd E, Mississauga \n\n Phone: 289 - 329 - 0371  \n\n Web: http://schools.peelschools.org/1354/Pages/default.aspx \n",
            "Rotherglen Motessori School \n\n 3553 South Commo, Mississauga \n\n Phone: 289 - 814 - 1458 \n\n Web: http://schools.peelschools.org/1154/Pages/default.aspx \n",
            "NorthStar Motessori Private School \n\n 4900 Tomken Road, Misissauga \n\n Phone: 905 - 890 - 7827 \n\n Web: http://schools.peelschools.org/1149/Pages/default.aspx \n",
            "Kendellhurst Academy \n\n 170 Church Street, Mississauga \n\n Phone: 905 - 568 - 1836 \n\n Web: http://schools.peelschools.org/1155/Pages/default.aspx \n",
            "The Thinnox Academy \n\n 755 Lakeshore Road E, Mississauga \n\n Phone: 905 - 270 - 0845 \n\n Web: http://schools.peelschools.org/1353/Pages/default.aspx \n",
            "Team School\n\n 275 Rudar Road, Mississauga \n\n Phone: 905 - 677 - 2202\n\n Web: http://schools.peelschools.org/1108/Pages/default.aspx \n"
    };

    Integer[] imageId = {R.drawable.privatelogo,
            R.drawable.privatelogo,
            R.drawable.privatelogo,
            R.drawable.privatelogo,
            R.drawable.privatelogo,
            R.drawable.privatelogo,
            R.drawable.privatelogo
    };

    public void startPrivateMap(View v){
        Intent intent = new Intent(SchoolPrivateActivity.this,privatemap.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private);

        CustomListPublic adapter = new CustomListPublic(SchoolPrivateActivity.this, info, imageId);
        privateList = (ListView)findViewById(R.id.listViewPrivate);
        privateList.setAdapter(adapter);
        privateList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Toast.makeText(SchoolPrivateActivity.this, "You Clicked at " + info[+ position], Toast.LENGTH_SHORT).show();
            }
        });
    }

}
