package com.example.kim.mississauga_school_app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SchoolCatholicActivity extends Activity{

    ListView catholicList;

    String[] info = {"All Saints separate School \n\n 4150 Colonial Drive, Mississauga \n\n Phone: 905 - 828 - 6348 \n\n Web: http://schools.peelschools.org/1360/Pages/default.aspx \n",
            "Archbishop Romero Catholic SS \n\n 2495 Credit Valeey Road, Mississauga \n\n Phone: 905 - 412 - 1000 \n\n Web: http://schools.peelschools.org/1354/Pages/default.aspx \n",
            "Ascension of Our Lord School\n\n 7640 Anaka Drive, Mississauga \n\n Phone: 905 - 676 - 1287 \n\n Web: http://schools.peelschools.org/1154/Pages/default.aspx \n",
            "Bishop Francis Allen School \n\n 225 Central Parkway, Mississauga \n\n Phone: 905 - 896 - 3665 \n\n Web: http://schools.peelschools.org/1149/Pages/default.aspx \n",
            "Blessed Teresa of Calcutta \n\n 1120 Runningbrook Drive, Mississauga \n\n Phone: 905 - 273 - 3937 \n\n Web: http://schools.peelschools.org/1155/Pages/default.aspx \n",
            "Canadian Martyrs Catholic School \n\n 1185 Mississauga Valley Blvd, Mississauga \n\n Phone: 905 - 275 - 0094 \n\n Web: http://schools.peelschools.org/1353/Pages/default.aspx \n",
            "Corpus Christi Separate School \n\n 4155 Elora Drive, Mississauga \n\n Phone: 905 - 897 - 7037 \n\n Web: http://schools.peelschools.org/1108/Pages/default.aspx \n"
    };

    Integer[] imageId = {R.drawable.catholiclogo,
            R.drawable.catholiclogo,
            R.drawable.catholiclogo,
            R.drawable.catholiclogo,
            R.drawable.catholiclogo,
            R.drawable.catholiclogo,
            R.drawable.catholiclogo
    };

    public void startCatholicMap(View v){
        Intent intent = new Intent(SchoolCatholicActivity.this,catholicmap.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catholic);

        CustomListPublic adapter = new CustomListPublic(SchoolCatholicActivity.this, info, imageId);
        catholicList = (ListView)findViewById(R.id.listViewCatholic);
        catholicList.setAdapter(adapter);
        catholicList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Toast.makeText(SchoolCatholicActivity.this, "You Clicked at " + info[+ position], Toast.LENGTH_SHORT).show();
            }
        });
    }

}