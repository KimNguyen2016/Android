package com.example.kim.tictactoeapp;

import android.app.Activity;
import android.graphics.Color;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener{

    Button a1, a2, a3;
    Button b1, b2, b3;
    Button c1, c2, c3;
    Button playButton, exitButton;

    Button[] bArray;
    boolean turn = true;
    int turn_count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        a1 = (Button)findViewById(R.id.A1);
        a2 = (Button)findViewById(R.id.A2);
        a3 = (Button)findViewById(R.id.A3);

        b1 = (Button)findViewById(R.id.B1);
        b2 = (Button)findViewById(R.id.B2);
        b3 = (Button)findViewById(R.id.B3);

        c1 = (Button)findViewById(R.id.C1);
        c2 = (Button)findViewById(R.id.C2);
        c3 = (Button)findViewById(R.id.C3);

        playButton = (Button)findViewById(R.id.btnPlayAgain);
        exitButton = (Button)findViewById(R.id.btnExit);

        bArray = new Button[]{a1, a2, a3,b1, b2, b3,c1, c2, c3};

        for (Button b: bArray){
            b.setOnClickListener(this);
            /*
             * this makes this class to handle the event
             * so this class should implement an interface called OnClickListener with has the function OnClick
            */
        }
    }

    @Override
    public void onClick(View v) {
        // this method will be called on every click
        //toast("Button has been clicked");

        Button b = (Button) v;
            turn_count++;
            buttonClicked(b);
    }


    public void buttonClicked(Button b){
        if (turn)
            b.setText("X");
        else
            b.setText("O");
        b.setBackgroundColor(Color.MAGENTA);
        b.setClickable(false);
        turn = !turn;

        checkForWinner();
    }

    private void checkForWinner(){
        String a1Char, a2Char, a3Char;
        String b1Char, b2Char, b3Char;
        String c1Char, c2Char, c3Char;

        a1Char = a1.getText().toString();
        a2Char = a2.getText().toString();
        a3Char = a3.getText().toString();

        b1Char = b1.getText().toString();
        b2Char = b2.getText().toString();
        b3Char = b3.getText().toString();

        c1Char = c1.getText().toString();
        c2Char = c2.getText().toString();
        c3Char = c3.getText().toString();

        boolean isWinner = false;
        /* For symbol X */

        // A
        if (a1Char == a2Char  && a2Char == a3Char && !a1.isClickable()) isWinner = true;
        else if (a1Char == b1Char && b1Char == c1Char && !a1.isClickable() ) isWinner = true;
        else if (a1Char == b2Char && b2Char == c3Char && !a1.isClickable() ) isWinner = true;
        else if (b1Char == b2Char && b2Char == b3Char && !b1.isClickable()) isWinner = true;
        else if (a2Char == b2Char && b2Char == c2Char && !b2.isClickable()) isWinner = true;
        else if (c1Char == b2Char && b2Char == a3Char && !b2.isClickable()) isWinner = true;
        else if (c1Char == c2Char && c2Char == c3Char && !c1.isClickable()) isWinner = true;
        else if (a3Char == b3Char && b3Char == c3Char && !c3.isClickable())isWinner = true;
        else if (c1Char == b2Char && b2Char == a3Char && !b2.isClickable()) isWinner = true;

        if (isWinner == true) {
            if (!turn)
                toast("You (X) win !!!!");
            else
                toast(" O wins");

            enableOrDisable(false);
        }
        else if (turn_count == 9)
                toast("Draw");
    }

    private void toast(String message){
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
    }

    private void enableOrDisable(boolean enable) {
        for (Button b : bArray) {
            b.setText("");
            b.setClickable(enable);
            if (enable) {
                b.setBackgroundColor(Color.parseColor("#33b5e5"));
            } else {
                b.setBackgroundColor(Color.MAGENTA);
            }
        }
    }

    public void exitGame(){
        System.exit(0);
    }
}
