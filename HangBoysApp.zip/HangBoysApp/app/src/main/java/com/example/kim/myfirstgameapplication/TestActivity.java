package com.example.kim.myfirstgameapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class TestActivity extends AppCompatActivity {
    String mWord="WORD";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);

        TextView tv = (TextView) findViewById(R.id.textView6);
        tv.setText("Welcome");
        setRandomWord();
    }

    public void setRandomWord(){
        String words = "GIRL LAND HOPE LOVE TALK LAMP PLAY";
        String[] arrayWords = words.split(" ");

        //Log.d("MYLOG", "The array Length " + arrayWords.length);
        int randomNumber = (int )(Math.random()* arrayWords.length);
        String randomWord = arrayWords[randomNumber];

        mWord = randomWord;
    }
}
