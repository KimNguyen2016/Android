package com.example.kim.myfirstgameapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

public class MyFirstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_first);
    }

    public void startSinglePlayerGame(View v){
        Intent myIntent = new Intent(this, GameActivity.class);
        startActivity(myIntent);

    }

    public void startMultiGame(View v){
        Intent myIntent = new Intent(this, MultiPlayerActivity.class);
        startActivity(myIntent);
    }

    public void openScores(View v){
        Intent myIntent = new Intent(this, ScoreActivity.class);
        startActivity(myIntent);
    }

    public void startTest(View v){
        Intent myIntent = new Intent(this,TestActivity.class);
        startActivity(myIntent);
    }

}
