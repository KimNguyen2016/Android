package com.example.kim.myfirstgameapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class GameActivity extends AppCompatActivity {

    String mWord="WORD";
    int mFailCounter = 0;
    int mGuessLeter = 0;
    int mPoint = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        setRandomWord();
    }

    /**
     * Retrieving the letter introduced on the editText
     * @param v (Button clicked)
     */

    public void introduceLetter(View v){
        EditText myEditText = (EditText)findViewById(R.id.editTextLetter);
        String letter = myEditText.getText().toString();
        myEditText.setText("");

        Log.d("MYLOG", "The letter introduced is " + letter);
        if (letter.length() > 0){
            checkLetter(letter.toUpperCase());
        } else{
            Toast.makeText(this, "Please Introduce Letter", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Checking if the letter introduced matches any letter in the word to guess
     * @param introducedLetter, letter introduced  by the user
     */
    public void checkLetter(String introducedLetter){
        char charIntroduced = introducedLetter.charAt(0);
        boolean letterGuessed = false;

        for (int i=0; i <mWord.length(); i++){
            char charFromTheWord = mWord.charAt(i);
            if (charFromTheWord == charIntroduced){
                Log.d("MYLOG", "There was one match");
                letterGuessed = true;
                showLetterAtIndex(i, charIntroduced);
                mGuessLeter ++;
            }
        }
        if (letterGuessed == false){
            letterFailed(Character.toString(charIntroduced));
        }

        if (mGuessLeter == mWord.length()){
            // score the point, clear the previous word and start the game.
            mPoint ++;
            Toast.makeText(this, "You Got It !", Toast.LENGTH_LONG).show();
            clearScreen();
            setRandomWord();




        }
    }

    public void letterFailed(String letterFailed){

        TextView textViewFailed = (TextView) findViewById(R.id.textViewLetterFailed);
        String previousFailed = textViewFailed.getText().toString();
        textViewFailed.setText(previousFailed + " " + letterFailed);
        mFailCounter ++;
        ImageView imageView = (ImageView)findViewById(R.id.imageView);

        if (mFailCounter ==1) imageView.setImageResource(R.drawable.stage1);
        else if (mFailCounter == 2) imageView.setImageResource(R.drawable.stage2);
        else if (mFailCounter ==3) imageView.setImageResource(R.drawable.stage3);
        else if (mFailCounter ==4) imageView.setImageResource(R.drawable.stage4);
        else if (mFailCounter ==5) imageView.setImageResource(R.drawable.stage5);
        else if (mFailCounter ==6) {
            //game over
            Intent gameOverIntent = new Intent(this, GameOverActivity.class);
            gameOverIntent.putExtra("POINTS", mPoint);
            startActivity(gameOverIntent);

        }

        //imageView.setImageDrawable();
    }

    /**
     * Displaying a letter guessed by the user
     * @param position of the letter
     * @param letterGuessed
     */
    public  void showLetterAtIndex(int position, char letterGuessed){
        LinearLayout layoutletter = (LinearLayout)findViewById(R.id.layoutLetters);
        TextView textView = (TextView) layoutletter.getChildAt(position);
        textView.setText(Character.toString(letterGuessed));
    }

    public void setRandomWord(){
        String words = "GIRL LAND HOPE LOVE TALK LAMP PLAY";
        String[] arrayWords = words.split(" ");

        //Log.d("MYLOG", "The array Length " + arrayWords.length);
        int randomNumber = (int )(Math.random()* arrayWords.length);
        String randomWord = arrayWords[randomNumber];

        mWord = randomWord;
    }


    public void clearScreen(){
        TextView textViewFailed = (TextView)findViewById(R.id.textViewLetterFailed);
        textViewFailed.setText("");
        mGuessLeter = 0;
        mFailCounter = 0;

        LinearLayout layoutLetter = (LinearLayout)findViewById(R.id.layoutLetters);
        for (int i =0; i<layoutLetter.getChildCount(); i++){
            TextView currentTextView = (TextView) layoutLetter.getChildAt(i);
            currentTextView.setText("_");

            ImageView imageView = (ImageView)findViewById(R.id.imageView);
            imageView.setImageResource(R.drawable.stage1);
        }
    }
}
